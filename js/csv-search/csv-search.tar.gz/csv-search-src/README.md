# Read and Display and search CSV File in Java

## System Design

Load the csv into memory then search in memory

## Usage
### Open IntelliJ
### Open Application class
### Run
### Then, in your browser, open http://localhost:8080/csv.
### open dog\_breed.csv, upload
### input Lab, click search 

